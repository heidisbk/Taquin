import pygame
import sys
import pygame.locals
import random
import time

pygame.init()

fenetre = pygame.display.set_mode((1200, 800))

pygame.display.set_caption("Taquin")
rectScreen = fenetre.get_rect()


def haut(cases, x, y):
    salut = cases[x][y]
    cases[x][y] = cases[x][y-1]
    cases[x][y-1] = salut
    print(cases)


def bas(cases, x, y):
    salut = cases[x][y]
    cases[x][y] = cases[x][y+1]
    cases[x][y+1] = salut
    print(cases)


def droite(cases, x, y):
    salut = cases[x][y]
    cases[x][y] = cases[x+1][y]
    cases[x+1][y] = salut
    print(cases)


def gauche(cases, x, y):
    salut = cases[x][y]
    cases[x][y] = cases[x-1][y]
    cases[x-1][y] = salut
    print(cases)


start = time.time()

to_begin = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
cases = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
random.shuffle(cases)
random.shuffle(cases[0])
random.shuffle(cases[1])
random.shuffle(cases[2])
print(cases)
print(cases[0][0])
print(cases[0][1])
print(cases[0][2])
print(cases[1][0])
print(cases[1][1])

reversed = [2, 1, 0]

font = pygame.font.Font(None, 48)
for i in range(3):                                                                     #ça n'affiche que la dernière valeur de cases[i][j]
    for j in range(3):
        texte = font.render(str(cases[i][j]), True, (180, 180, 180))
victoire = font.render(("Tu as gagné, bien joué !"), True, (180, 180, 180))
#texte2 = police.render(cases, True, pygame.Color("#FFFF00"))
rectTexte = texte.get_rect()

nombre_coup = 0

couleur = (200, 30, 30)
couleur_vide = (255, 240, 240)

run = 1

while run == 1:
    for event in pygame.event.get():
        print(event)

        if event.type == pygame.locals.QUIT:
            pygame.quit()
            sys.exit(0)

        if event.type == pygame.locals.KEYDOWN and event.key == pygame.K_UP:
            for i in range(3):
                for j in range(3):
                    if j != 0:
                        if cases[i][j] == 0:
                            haut(cases, i, j)
                            break

        if event.type == pygame.locals.KEYDOWN and event.key == pygame.K_DOWN:
            for i in range(3):
                for j in range(3):
                    if j != 2:
                        if cases[i][j] == 0:
                            bas(cases, i, j)
                            break

        if event.type == pygame.locals.KEYDOWN and event.key == pygame.K_RIGHT:
            for i in reversed:
                for j in range(3):
                    if i != 2:
                        if cases[i][j] == 0:
                            droite(cases, i, j)
                            break

        if event.type == pygame.locals.KEYDOWN and event.key == pygame.K_LEFT:
            for i in range(3):
                for j in range(3):
                    if i != 0:
                        if cases[i][j] == 0:
                            gauche(cases, i, j)
                            break

    fond = pygame.image.load("/home/heidi/PycharmProjects/PYGAME/Images/gazon.png").convert()               #le chemin doit sans doute être modifier pour pouvoir charger la photo
    fenetre.blit(fond, (0, 0))

    for i in range(3):
        for j in range(3):
            if cases[i][j] == 0:
                pygame.draw.rect(fenetre, couleur_vide, (360+(160*i), 120+(160*j), 150, 150))
            else:
                rect = pygame.Rect((360+(160*i), 120+(160*j), 150, 150))
                rectangle = pygame.draw.rect(fenetre, couleur, rect)
                rectTexte.center = rect.center
                fenetre.blit(texte, rectTexte)
    if cases == to_begin:
        fenetre.blit(victoire, (400, 700))

    #pygame.draw.rect(fenetre, (100, 100, 100), (25, 160+25, 150, 150))
    #pygame.draw.rect(fenetre, (100, 100, 100), (25, 25+160*2, 150, 150))

    pygame.display.update()
